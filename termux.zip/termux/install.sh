pkg install tesseract
npm i -g cwebp
npm i -g ytdl
npm i node-tesseract-ocr
npm i
npm i got
